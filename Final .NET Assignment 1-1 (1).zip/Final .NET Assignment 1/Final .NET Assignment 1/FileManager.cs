﻿using System.Collections.Generic;

namespace HospitalManagementSystem
{
    public static class FileManager
    {
        public static List<Patient> patients = new List<Patient>();
        public static List<Doctor> doctors = new List<Doctor>();
        public static List<Appointment> appointments = new List<Appointment>();
        public static List<Administrator> administrators = new List<Administrator>();

        public static void LoadData()
        {
            patients = Patient.LoadPatientsFromFile("patients.txt");
            doctors = Doctor.LoadDoctorsFromFile("doctors.txt");
            appointments = Appointment.LoadAppointmentsFromFile("appointments.txt", doctors, patients);
            administrators = Administrator.LoadAdministratorsFromFile("administrators.txt");
        }

        public static void SaveData()
        {
            Patient.SavePatientsToFile("patients.txt", patients);
            Doctor.SaveDoctorsToFile("doctors.txt", doctors);
            Appointment.SaveAppointmentsToFile("appointments.txt", appointments);
            Administrator.SaveAdministratorsToFile("administrators.txt", administrators);
        }
    }
}

