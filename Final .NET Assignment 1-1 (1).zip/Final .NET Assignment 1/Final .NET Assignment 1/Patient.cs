﻿using System;
using System.Collections.Generic;
using Microsoft.VisualBasic.FileIO;
using System.IO;

namespace HospitalManagementSystem
{
    // The Patient class represents a hospital patient and inherits from the User class.
    // It also implements IDisposable to manage resource cleanup.
    public class Patient : User, IDisposable
    {
        // Properties to hold patient details such as address, email, phone, and assigned doctor.
        public string Address { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public Doctor AssignedDoctor { get; set; }
        public List<Appointment> Appointments { get; private set; } = new List<Appointment>();

        // Field to keep track of whether the object has been disposed.
        private bool disposed = false;

        // Constructor to initialize a new Patient object with required details.
        public Patient(int id, string name, string password, string address, string email, string phone)
            : base(id, name, password)
        {
            Address = address;
            Email = email;
            Phone = phone;
        }

        // Overrides the ToString method to provide a formatted string representation of patient details.
        public override string ToString()
        {
            return $"{Name,-18} | {AssignedDoctor?.Name ?? "No Doctor",-18} | {Email,-25} | {Phone,-13} | {Address,-30}";
        }

        // Displays the patient-specific menu and handles user input for patient actions.
        public override void MainMenu()
        {
            bool exit = false;
            while (!exit)
            {
                Console.Clear();
                Console.WriteLine("-------------------------------");
                Console.WriteLine("| DOTNET Hospital Management System |");
                Console.WriteLine("-------------------------------\n");
                Console.WriteLine("Patient Menu\n");
                Console.WriteLine($"Welcome to DOTNET Hospital Management System {Name}\n");

                Console.WriteLine("Please choose an option:");
                Console.WriteLine("1. List patient details");
                Console.WriteLine("2. List my doctor details");
                Console.WriteLine("3. List all appointments");
                Console.WriteLine("4. Book appointment");
                Console.WriteLine("5. Exit to login");
                Console.WriteLine("6. Exit System");
                Console.Write("Select option: ");
                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        ListPatientDetails();
                        break;
                    case "2":
                        ListDoctorDetails();
                        break;
                    case "3":
                        ListAppointments();
                        break;
                    case "4":
                        MenuManager.BookAppointment(this);
                        break;
                    case "5":
                        exit = true; // Return to login
                        Program.Main(new string[] { });
                        break;
                    case "6":
                        Environment.Exit(0); // Exit the program
                        break;
                    default:
                        Console.WriteLine("Invalid option. Please try again.");
                        break;
                }
            }
        }

        // Implement the IDisposable interface to allow manual resource cleanup.
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this); // Suppress finalization if Dispose() is called.
        }

        // Method to handle resource cleanup, both managed and unmanaged.
        protected virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                {
                    // Cleanup managed resources such as clearing appointments.
                    Appointments.Clear();
                    Console.WriteLine($"{Name}'s resources cleaned up.");
                }

                // Cleanup unmanaged resources if any (not applicable here).
                disposed = true;
            }
        }

        // Finalizer to ensure cleanup happens if Dispose() is not called.
        ~Patient()
        {
            Dispose(false);
        }

        // Displays full details of the patient, including ID, name, and contact details.
        public void ListPatientDetails()
        {
            Console.Clear();
            Console.WriteLine("-------------------------------");
            Console.WriteLine("| DOTNET Hospital Management System |");
            Console.WriteLine("-------------------------------\n");
            Console.WriteLine("My Full Details\n");

            Console.WriteLine($"Patient ID: {ID}");
            Console.WriteLine($"Full Name: {Name}");
            Console.WriteLine($"Address: {Address}");
            Console.WriteLine($"Email: {Email}");
            Console.WriteLine($"Phone: {Phone}");
            Console.WriteLine("\nPress any key to return to menu.");
            Console.ReadKey();
        }

        // Overloaded method to display either basic or full patient details.
        public void ListPatientDetails(bool basic)
        {
            if (basic)
            {
                // Display only basic details if 'basic' is true.
                Console.WriteLine($"Patient: {Name} | Email: {Email}");
            }
            else
            {
                // Call the full details method if 'basic' is false.
                ListPatientDetails();
            }
        }

        // Displays details of the assigned doctor if one is available.
        public void ListDoctorDetails()
        {
            Console.Clear();
            Console.WriteLine("-------------------------------");
            Console.WriteLine("| DOTNET Hospital Management System |");
            Console.WriteLine("-------------------------------\n");
            Console.WriteLine("My Doctor Details\n");

            if (AssignedDoctor != null)
            {
                Console.WriteLine("Name                 | Email Address           | Phone       | Address");
                Console.WriteLine("---------------------|-------------------------|-------------|--------------------------");
                Console.WriteLine($"{AssignedDoctor.Name,-20} | {AssignedDoctor.Email,-23} | {AssignedDoctor.Phone,-11} | {AssignedDoctor.Address}");
            }
            else
            {
                Console.WriteLine("No doctor assigned.");
            }

            Console.WriteLine("\nPress any key to return to menu.");
            Console.ReadKey();
        }

        // Displays a list of all appointments associated with this patient.
        public void ListAppointments()
        {
            Console.Clear();
            Console.WriteLine("-------------------------------");
            Console.WriteLine("| DOTNET Hospital Management System |");
            Console.WriteLine("-------------------------------\n");
            Console.WriteLine($"Appointments for {Name}\n");

            if (Appointments.Count > 0)
            {
                Console.WriteLine("Doctor               | Patient              | Description");
                Console.WriteLine("-------------------- | -------------------- | -----------------------------");

                foreach (var appointment in Appointments)
                {
                    Console.WriteLine($"{appointment.Doctor.Name,-20} | {appointment.Patient.Name,-20} | {appointment.Description}");
                }
            }
            else
            {
                Console.WriteLine("No appointments found.");
            }

            Console.WriteLine("\nPress any key to return to the menu.");
            Console.ReadKey();
        }

        // Loads patient data from a file into a list of Patient objects.
        public static List<Patient> LoadPatientsFromFile(string filePath)
        {
            List<Patient> patients = new List<Patient>();

            try
            {
                if (!File.Exists(filePath))
                {
                    Console.WriteLine($"Error: File not found at {filePath}");
                    return patients;
                }

                using (TextFieldParser parser = new TextFieldParser(filePath))
                {
                    parser.TextFieldType = FieldType.Delimited;
                    parser.SetDelimiters(",");  // Use a comma as the delimiter

                    while (!parser.EndOfData)
                    {
                        string[] fields = parser.ReadFields();

                        if (fields.Length == 6)
                        {
                            int id = int.Parse(fields[0]);
                            string name = fields[1];
                            string password = fields[2];
                            string address = fields[3];
                            string email = fields[4];
                            string phone = fields[5];

                            // Create a new Patient object and add it to the list.
                            Patient newPatient = new Patient(id, name, password, address, email, phone);
                            patients.Add(newPatient);
                        }
                        else
                        {
                            Console.WriteLine($"Error: Invalid line format. Expected 6 fields but found {fields.Length}.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error loading patient file: {ex.Message}");
            }

            return patients;
        }

        // Saves the list of Patient objects to a file.
        public static void SavePatientsToFile(string filePath, List<Patient> patients)
        {
            using (StreamWriter writer = new StreamWriter(filePath))
            {
                foreach (var patient in patients)
                {
                    writer.WriteLine($"{patient.ID},{patient.Name},{patient.Password},\"{patient.Address}\",{patient.Email},{patient.Phone}");
                }
            }
        }
    }
}




