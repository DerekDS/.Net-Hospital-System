﻿using System.Collections.Generic;
using Microsoft.VisualBasic.FileIO;
using System.IO;

namespace HospitalManagementSystem
{
    public class Administrator : User
    {
        // Properties for Address, Email, and Phone of the Administrator
        public string Address { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }

        // Constructor to initialize Administrator object with the given values
        public Administrator(int id, string name, string password, string address, string email, string phone)
            : base(id, name, password)
        {
            Address = address;
            Email = email;
            Phone = phone;
        }

        // Overrides MainMenu to call Admin-specific menu
        public override void MainMenu()
        {
            MenuManager.AdminMenu(this);
        }

        // Load administrator data from a file
        public static List<Administrator> LoadAdministratorsFromFile(string filePath)
        {
            List<Administrator> administrators = new List<Administrator>();

            // Check if the file exists before attempting to load
            if (!File.Exists(filePath))
            {
                System.Console.WriteLine($"Error: File not found at {filePath}");
                return administrators;
            }

            // Read the file and parse administrator data
            using (TextFieldParser parser = new TextFieldParser(filePath))
            {
                parser.TextFieldType = FieldType.Delimited;
                parser.SetDelimiters(",");

                while (!parser.EndOfData)
                {
                    try
                    {
                        string[] fields = parser.ReadFields();

                        // Ensure the correct number of fields before creating an Administrator object
                        if (fields.Length == 6)
                        {
                            int id = int.Parse(fields[0]);
                            string name = fields[1];
                            string password = fields[2];
                            string address = fields[3];
                            string email = fields[4];
                            string phone = fields[5];

                            Administrator newAdmin = new Administrator(id, name, password, address, email, phone);
                            administrators.Add(newAdmin);
                        }
                        else
                        {
                            System.Console.WriteLine($"Error: Invalid line format. Expected 6 fields but found {fields.Length}.");
                        }
                    }
                    catch (System.Exception ex)
                    {
                        System.Console.WriteLine($"Error loading administrator: {ex.Message}");
                    }
                }
            }

            return administrators;
        }

        // Save administrator data to a file
        public static void SaveAdministratorsToFile(string filePath, List<Administrator> administrators)
        {
            using (StreamWriter writer = new StreamWriter(filePath))
            {
                // Write each administrator's details in CSV format
                foreach (var admin in administrators)
                {
                    writer.WriteLine($"{admin.ID},{admin.Name},{admin.Password},\"{admin.Address}\",{admin.Email},{admin.Phone}");
                }
            }
        }
    }
}


