﻿using System;

namespace HospitalManagementSystem
{
    // The Program class serves as the entry point for the hospital management system.
    class Program
    {
        // Main method: Entry point of the application
        public static void Main(string[] args)
        {
            // Load data for patients, doctors, and appointments from files using FileManager
            FileManager.LoadData();

            bool loginSuccess = false;

            // Loop until a user successfully logs in
            while (!loginSuccess)
            {
                Console.Clear();
                // Display login screen
                Console.WriteLine(" ___________________________________");
                Console.WriteLine("|                                   |");
                Console.WriteLine("| DOTNET Hospital Management System |");
                Console.WriteLine("|-----------------------------------|");
                Console.WriteLine("|               Login               |");
                Console.WriteLine("|___________________________________|\n");

                // Ask user for their ID and password
                Console.Write("ID: ");
                int id = int.Parse(Console.ReadLine());

                Console.Write("Password: ");
                string password = ReadPassword();

                // Attempt to login using the credentials entered
                loginSuccess = MenuManager.Login(id, password);

                // If login fails, notify the user and allow them to try again
                if (!loginSuccess)
                {
                    Console.WriteLine("\nInvalid Credentials. Please try again.");
                    Console.ReadKey();
                }
            }

            // Save data before exiting the system
            FileManager.SaveData();
        }

        static string ReadPassword()
        {
            string password = ""; // Password will be stored here
            ConsoleKeyInfo key; // To store the pressed key info

            do
            {
                key = Console.ReadKey(true); // Read key without displaying it

                // Add character to password and show '*' for each character typed
                if (key.Key != ConsoleKey.Backspace && key.Key != ConsoleKey.Enter)
                {
                    password += key.KeyChar;
                    Console.Write("*");
                }
                // Handle backspace: remove last character from password
                else if (key.Key == ConsoleKey.Backspace && password.Length > 0)
                {
                    password = password.Substring(0, password.Length - 1);
                    Console.Write("\b \b"); // Move the cursor back and erase the '*'
                }
            } while (key.Key != ConsoleKey.Enter); // Stop reading input when 'Enter' is pressed

            Console.WriteLine(); // Move to the next line after password is entered
            return password; 
        }
    }
}


