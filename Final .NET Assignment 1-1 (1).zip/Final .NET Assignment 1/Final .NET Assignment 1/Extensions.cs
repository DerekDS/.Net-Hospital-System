﻿public static class Extensions
{
    public static string PadRightCustom(this string input, int totalLength)
    {
        return input.PadRight(totalLength, ' ');
    }
}

