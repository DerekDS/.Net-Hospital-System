﻿using System;
using System.Collections.Generic;
using System.IO;

namespace HospitalManagementSystem
{
    public class Appointment
    {
        // Properties to hold doctor, patient, and description of the appointment
        public Doctor Doctor { get; set; }
        public Patient Patient { get; set; }
        public string Description { get; set; }

        // Constructor to initialize an appointment with a doctor, patient, and description
        public Appointment(Doctor doctor, Patient patient, string description)
        {
            Doctor = doctor;
            Patient = patient;
            Description = description;
        }

        // Override ToString to return formatted appointment details
        public override string ToString()
        {
            return $"{Doctor.Name,-16} | {Patient.Name,-17} | {Description}";
        }

        // Loads appointment data from the specified file and links them to doctors and patients
        public static List<Appointment> LoadAppointmentsFromFile(string filePath, List<Doctor> doctors, List<Patient> patients)
        {
            List<Appointment> appointments = new List<Appointment>();

            if (File.Exists(filePath))
            {               
                string[] lines = File.ReadAllLines(filePath);

                foreach (string line in lines)
                {
                    string[] parts = line.Split(',');

                    if (parts.Length == 3)
                    {
                        int doctorId = int.Parse(parts[0]);
                        int patientId = int.Parse(parts[1]);
                        string description = parts[2];

                        // Find the matching doctor and patient based on their IDs
                        Doctor doctor = doctors.Find(d => d.ID == doctorId);
                        Patient patient = patients.Find(p => p.ID == patientId);

                        if (doctor != null && patient != null)
                        {
                            // Create a new appointment and add it to the list
                            Appointment newAppointment = new Appointment(doctor, patient, description);
                            appointments.Add(newAppointment);

                            // Assign the doctor to the patient
                            patient.AssignedDoctor = doctor;

                            // Add the patient to the doctor's list if not already present
                            if (!doctor.Patients.Contains(patient))
                            {
                                doctor.Patients.Add(patient);
                            }

                            // Add the appointment to the patient's list if not already present
                            if (!patient.Appointments.Contains(newAppointment))
                            {
                                patient.Appointments.Add(newAppointment);
                            }
                        }
                        else
                        {
                            Console.WriteLine($"Warning: Doctor or Patient not found for Doctor ID: {doctorId}, Patient ID: {patientId}");
                        }
                    }
                }
            }
            else
            {
                // If the file does not exist, display an error message
                Console.WriteLine($"Error: File not found at {filePath}");
            }

            return appointments;
        }
        public static void SaveAppointmentsToFile(string filePath, List<Appointment> appointments)
        {
            // Write each appointment as a comma-separated line in the file
            using (StreamWriter writer = new StreamWriter(filePath))
            {
                foreach (var appointment in appointments)
                {
                    writer.WriteLine($"{appointment.Doctor.ID},{appointment.Patient.ID},{appointment.Description}");
                }
            }
        }
    }
}
