﻿using System;

namespace HospitalManagementSystem
{
    public static class MenuManager
    {
        // Handles the login process for Patients, Doctors, and Administrators
        public static bool Login(int id, string password)
        {
            // Check if a Patient exists with the provided ID and password
            Patient foundPatient = FileManager.patients.Find(p => p.ID == id && p.Password == password);
            if (foundPatient != null)
            {
                Console.WriteLine("\nValid Credentials");
                foundPatient.MainMenu();
                return true;
            }

            // Check if a Doctor exists with the provided ID and password
            Doctor foundDoctor = FileManager.doctors.Find(d => d.ID == id && d.Password == password);
            if (foundDoctor != null)
            {
                Console.WriteLine("\nValid Credentials");
                foundDoctor.MainMenu();
                return true;
            }

            // Check if an Administrator exists with the provided ID and password
            Administrator foundAdmin = FileManager.administrators.Find(a => a.ID == id && a.Password == password);
            if (foundAdmin != null)
            {
                Console.WriteLine("\nValid Credentials");
                foundAdmin.MainMenu();
                return true;
            }

            // If no match found, return false (invalid login)
            return false;
        }

        // Displays the Administrator's menu and handles their choices
        public static void AdminMenu(Administrator admin)
        {
            bool exit = false;
            while (!exit)
            {
                Console.Clear();
                Console.WriteLine("-------------------------------");
                Console.WriteLine("| DOTNET Hospital Management System |");
                Console.WriteLine("-------------------------------");
                Console.WriteLine("Administrator Menu\n");
                Console.WriteLine($"Welcome to DOTNET Hospital Management System {admin.Name}\n");

                Console.WriteLine("Please choose an option:");
                Console.WriteLine("1. List all doctors");
                Console.WriteLine("2. Check doctor details");
                Console.WriteLine("3. List all patients");
                Console.WriteLine("4. Check patient details");
                Console.WriteLine("5. Add doctor");
                Console.WriteLine("6. Add patient");
                Console.WriteLine("7. Logout");
                Console.WriteLine("8. Exit");
                Console.Write("Select option: ");
                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        ListAllDoctors();
                        break;
                    case "2":
                        CheckDoctorDetails();
                        break;
                    case "3":
                        ListAllPatients();
                        break;
                    case "4":
                        CheckPatientDetails();
                        break;
                    case "5":
                        AddDoctor();
                        break;
                    case "6":
                        AddPatient();
                        break;
                    case "7":
                        exit = true;
                        Program.Main(new string[] { });
                        break;
                    case "8":
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Invalid option. Please try again.");
                        break;
                }
            }
        }

        // Lists all doctors currently in the system
        public static void ListAllDoctors()
        {
            Console.Clear();
            Console.WriteLine("-------------------------------");
            Console.WriteLine("| DOTNET Hospital Management System |");
            Console.WriteLine("-------------------------------\n");
            Console.WriteLine("All Doctors registered to the DOTNET Hospital Management System\n");

            Console.WriteLine("Name                 | Email Address        | Phone         | Address");
            Console.WriteLine("---------------------|----------------------|---------------|------------------------------");

            foreach (var doctor in FileManager.doctors)
            {
                Console.WriteLine($"{doctor.Name,-20} | {doctor.Email,-20} | {doctor.Phone,-13} | {doctor.Address,-30}");
            }

            Console.WriteLine("\nPress any key to return to the menu.");
            Console.ReadKey();
        }

        // Allows the admin to check details of a specific doctor by their ID
        public static void CheckDoctorDetails()
        {
            Console.Clear();
            Console.WriteLine("-------------------------------");
            Console.WriteLine("| DOTNET Hospital Management System |");
            Console.WriteLine("-------------------------------\n");
            Console.WriteLine("Doctor Details\n");

            Console.Write("Please enter the ID of the doctor whose details you are checking. Or press 'n' to return to menu: ");
            string input = Console.ReadLine();

            if (input.ToLower() == "n")
            {
                return; // return to admin menu
            }

            if (int.TryParse(input, out int doctorId))
            {
                Doctor foundDoctor = FileManager.doctors.Find(d => d.ID == doctorId);

                if (foundDoctor != null)
                {
                    Console.Clear();
                    Console.WriteLine("-------------------------------");
                    Console.WriteLine("| DOTNET Hospital Management System |");
                    Console.WriteLine("-------------------------------\n");
                    Console.WriteLine($"Details for {foundDoctor.Name}\n");

                    Console.WriteLine("Name                 | Email Address             | Phone         | Address");
                    Console.WriteLine("---------------------|---------------------------|---------------|------------------------------");
                    Console.WriteLine($"{foundDoctor.Name,-20} | {foundDoctor.Email,-25} | {foundDoctor.Phone,-13} | {foundDoctor.Address,-30}");
                }
                else
                {
                    Console.WriteLine("\nError: No doctor found with the given ID.");
                }
            }
            else
            {
                Console.WriteLine("\nError: Invalid input. Please enter a valid numeric ID.");
            }

            Console.WriteLine("\nPress any key to return to the menu.");
            Console.ReadKey();
        }

        // Lists all patients currently in the system
        public static void ListAllPatients()
        {
            Console.Clear();
            Console.WriteLine("-------------------------------");
            Console.WriteLine("| DOTNET Hospital Management System |");
            Console.WriteLine("-------------------------------\n");
            Console.WriteLine("All patients registered to the DOTNET Hospital Management System\n");

            Console.WriteLine("Patient            | Doctor             | Email Address             | Phone         | Address");
            Console.WriteLine("-------------------|--------------------|---------------------------|---------------|------------------------------");

            foreach (var patient in FileManager.patients)
            {
                Console.WriteLine(patient.ToString());
            }

            Console.WriteLine("\nPress any key to return to the menu.");
            Console.ReadKey();
        }

        // Allows the admin to check details of a specific patient by their ID
        public static void CheckPatientDetails()
        {
            Console.Clear();
            Console.WriteLine("-------------------------------");
            Console.WriteLine("| DOTNET Hospital Management System |");
            Console.WriteLine("-------------------------------\n");
            Console.WriteLine("Patient Details\n");

            Console.Write("Please enter the ID of the patient whose details you are checking. Or press 'n' to return to menu: ");
            string input = Console.ReadLine();

            if (input.ToLower() == "n")
            {
                return; // return to admin menu
            }

            if (int.TryParse(input, out int patientId))
            {
                Patient foundPatient = FileManager.patients.Find(p => p.ID == patientId);

                if (foundPatient != null)
                {
                    Console.Clear();
                    Console.WriteLine("-------------------------------");
                    Console.WriteLine("| DOTNET Hospital Management System |");
                    Console.WriteLine("-------------------------------\n");
                    Console.WriteLine($"Details for {foundPatient.Name}\n");

                    Console.WriteLine("Patient              | Doctor              | Email Address             | Phone         | Address");
                    Console.WriteLine("---------------------|---------------------|---------------------------|---------------|------------------------------");

                    string doctorName = foundPatient.AssignedDoctor != null ? foundPatient.AssignedDoctor.Name : "No Doctor";
                    Console.WriteLine($"{foundPatient.Name,-20} | {doctorName,-19} | {foundPatient.Email,-25} | {foundPatient.Phone,-13} | {foundPatient.Address,-30}");
                }
                else
                {
                    Console.WriteLine("\nError: No patient found with the given ID.");
                }
            }
            else
            {
                Console.WriteLine("\nError: Invalid input. Please enter a valid numeric ID.");
            }

            Console.WriteLine("\nPress any key to return to the menu.");
            Console.ReadKey();
        }

        // Adds a new doctor to the system
        public static void AddDoctor()
        {
            Console.Clear();
            Console.WriteLine("-------------------------------");
            Console.WriteLine("| DOTNET Hospital Management System |");
            Console.WriteLine("-------------------------------\n");
            Console.WriteLine("Registering a new doctor with the DOTNET Hospital Management System\n");

            Console.Write("First Name: ");
            string firstName = Console.ReadLine();

            Console.Write("Last Name: ");
            string lastName = Console.ReadLine();

            Console.Write("Email: ");
            string email = Console.ReadLine();

            Console.Write("Phone: ");
            string phone = Console.ReadLine();

            Console.Write("Street Number: ");
            string streetNumber = Console.ReadLine();

            Console.Write("Street: ");
            string street = Console.ReadLine();

            Console.Write("City: ");
            string city = Console.ReadLine();

            Console.Write("State: ");
            string state = Console.ReadLine();

            string fullName = firstName + " " + lastName;
            string address = $"{streetNumber} {street}, {city}, {state}";

            // Generate a unique ID for the new doctor
            int id = FileManager.doctors.Count + 20001;

            // Create the new Doctor object
            Doctor newDoctor = new Doctor(id, fullName, "placeholderPass", address, email, phone);

            // Add the new doctor to the list
            FileManager.doctors.Add(newDoctor);

            // Save the new doctor to doctors.txt
            Doctor.SaveDoctorsToFile("doctors.txt", FileManager.doctors);

            Console.WriteLine($"\nDr {firstName} {lastName} added to the system!");
            Console.ReadKey();
        }

        // Adds a new patient to the system
        public static void AddPatient()
        {
            Console.Clear();
            Console.WriteLine("-------------------------------");
            Console.WriteLine("| DOTNET Hospital Management System |");
            Console.WriteLine("-------------------------------\n");
            Console.WriteLine("Registering a new patient with the DOTNET Hospital Management System\n");

            Console.Write("First Name: ");
            string firstName = Console.ReadLine();

            Console.Write("Last Name: ");
            string lastName = Console.ReadLine();

            Console.Write("Email: ");
            string email = Console.ReadLine();

            Console.Write("Phone: ");
            string phone = Console.ReadLine();

            Console.Write("Street Number: ");
            string streetNumber = Console.ReadLine();

            Console.Write("Street: ");
            string street = Console.ReadLine();

            Console.Write("City: ");
            string city = Console.ReadLine();

            Console.Write("State: ");
            string state = Console.ReadLine();

            string fullName = firstName + " " + lastName;
            string address = $"{streetNumber} {street}, {city}, {state}";

            // Generate a unique ID for the new patient
            int id = FileManager.patients.Count + 10001;

            // Create the new Patient object
            Patient newPatient = new Patient(id, fullName, "defaultPassword", address, email, phone);

            // Add the new patient to the list
            FileManager.patients.Add(newPatient);

            // Save the new patient to patients.txt
            Patient.SavePatientsToFile("patients.txt", FileManager.patients);

            Console.WriteLine($"\n{firstName} {lastName} added to the system!");
            Console.ReadKey();
        }

        // Books an appointment for a patient with their assigned doctor
        public static void BookAppointment(Patient patient)
        {
            if (patient.AssignedDoctor == null)
            {
                Console.WriteLine("You are not registered with any doctor! Please choose a doctor to register with:");

                foreach (var doctor in FileManager.doctors)
                {
                    Console.WriteLine($"{doctor.ID} | {doctor.Name} | {doctor.Email} | {doctor.Phone} | {doctor.Address}");
                }

                Console.Write("\nPlease enter the Doctor's ID to register: ");
                int doctorId = int.Parse(Console.ReadLine());

                Doctor selectedDoctor = FileManager.doctors.Find(d => d.ID == doctorId);

                if (selectedDoctor != null)
                {
                    patient.AssignedDoctor = selectedDoctor;
                    selectedDoctor.Patients.Add(patient);
                    Console.WriteLine($"\nYou are now registered with Dr. {selectedDoctor.Name}\n");
                }
                else
                {
                    Console.WriteLine("Invalid Doctor ID. Returning to menu.");
                    return;
                }
            }

            Console.Clear();
            Console.WriteLine("-------------------------------");
            Console.WriteLine("| DOTNET Hospital Management System |");
            Console.WriteLine("-------------------------------\n");
            Console.WriteLine("Book Appointment\n");

            Console.WriteLine($"You are booking a new appointment with Dr. {patient.AssignedDoctor.Name}");
            Console.Write("Please enter a short description of the appointment: ");
            string appointmentDescription = Console.ReadLine();

            // Create the appointment and assign the description
            Appointment newAppointment = new Appointment(patient.AssignedDoctor, patient, appointmentDescription);

            // Add the new appointment to the global appointments list
            FileManager.appointments.Add(newAppointment);

            // Also add the new appointment to the patient's list
            patient.Appointments.Add(newAppointment);

            // Save the updated list of appointments to the file
            Appointment.SaveAppointmentsToFile("appointments.txt", FileManager.appointments);

            Console.WriteLine("\nThe appointment has been booked successfully and saved to appointments.txt.");
            Console.WriteLine("Press any key to return to the menu.");
            Console.ReadKey();
        }

        // Lists all appointments for a doctor
        public static void ListAppointmentsForDoctor(Doctor doctor)
        {
            Console.Clear();
            Console.WriteLine("-------------------------------");
            Console.WriteLine("| DOTNET Hospital Management System |");
            Console.WriteLine("-------------------------------\n");
            Console.WriteLine("All Appointments\n");

            if (FileManager.appointments.Count > 0)
            {
                // Print table headers
                Console.WriteLine("Doctor               | Patient              | Description");
                Console.WriteLine("---------------------|----------------------|--------------------------------");

                // Loop through all appointments for this doctor
                foreach (var appointment in FileManager.appointments)
                {
                    if (appointment.Doctor.ID == doctor.ID)
                    {
                        Console.WriteLine($"{appointment.Doctor.Name,-20} | {appointment.Patient.Name,-20} | {appointment.Description}");
                    }
                }
            }
            else
            {
                Console.WriteLine("No appointments found.");
            }

            Console.WriteLine("\nPress any key to return to the menu.");
            Console.ReadKey();
        }
    }
}


