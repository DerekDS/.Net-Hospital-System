﻿namespace HospitalManagementSystem
{
    public class User
    {
        public int ID { get; protected set; }
        public string Name { get; protected set; }
        public string Password { get; protected set; }

        public User(int id, string name, string password)
        {
            ID = id;
            Name = name;
            Password = password;
        }

        public virtual void MainMenu() { }
    }
}

