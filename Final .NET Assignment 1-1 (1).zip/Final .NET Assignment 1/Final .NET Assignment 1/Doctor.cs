﻿using System;
using System.Collections.Generic;
using Microsoft.VisualBasic.FileIO;
using System.IO;

namespace HospitalManagementSystem
{
    // The Doctor class represents a doctor in the hospital and inherits from the User class.
    public class Doctor : User
    {
        // Properties to hold doctor's details such as address, email, and phone number.
        public string Address { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public List<Patient> Patients { get; private set; } = new List<Patient>();

        // Constructor to initialize a new Doctor object with required details.
        public Doctor(int id, string name, string password, string address, string email, string phone)
            : base(id, name, password)
        {
            Address = address;
            Email = email;
            Phone = phone;
        }

        // Displays the doctor-specific menu and handles user input for various actions.
        public override void MainMenu()
        {
            bool exit = false;
            while (!exit)
            {
                Console.Clear();
                Console.WriteLine("=== Doctor Menu ===");
                Console.WriteLine("1. List Doctor Details");
                Console.WriteLine("2. List Patients");
                Console.WriteLine("3. List Appointments");
                Console.WriteLine("4. Check Particular Patient");
                Console.WriteLine("5. List Appointments With Patient");
                Console.WriteLine("6. Logout");
                Console.WriteLine("7. Exit");
                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        ListDoctorDetails();
                        break;
                    case "2":
                        ListPatients();
                        break;
                    case "3":
                        MenuManager.ListAppointmentsForDoctor(this);
                        break;
                    case "4":
                        CheckPatientDetails();
                        break;
                    case "5":
                        ListAppointmentsWithPatient();
                        break;
                    case "6":
                        exit = true;
                        Program.Main(new string[] { });
                        break;
                    case "7":
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Invalid option. Please try again.");
                        break;
                }
            }
        }

        // Displays the full details of the doctor such as name, email, phone, and address.
        public void ListDoctorDetails()
        {
            Console.Clear();
            Console.WriteLine("-------------------------------");
            Console.WriteLine("| DOTNET Hospital Management System |");
            Console.WriteLine("-------------------------------\n");
            Console.WriteLine("My Details\n");

            Console.WriteLine("Name                 | Email Address           | Phone       | Address");
            Console.WriteLine("---------------------|-------------------------|-------------|--------------------------");
            Console.WriteLine($"{Name,-20} | {Email,-23} | {Phone,-11} | {Address}");

            Console.WriteLine("\nPress any key to return to menu.");
            Console.ReadKey();
        }

        // Lists all patients assigned to the doctor, if any.
        public void ListPatients()
        {
            Console.Clear();
            Console.WriteLine("-------------------------------");
            Console.WriteLine("| DOTNET Hospital Management System |");
            Console.WriteLine("-------------------------------\n");
            Console.WriteLine($"Patients assigned to Dr. {Name}:\n");

            if (Patients.Count > 0)
            {
                Console.WriteLine("Patient            | Doctor             | Email Address             | Phone         | Address");
                Console.WriteLine("-------------------|--------------------|---------------------------|---------------|------------------------------");

                HashSet<Patient> uniquePatients = new HashSet<Patient>(Patients);

                foreach (var patient in uniquePatients)
                {
                    Console.WriteLine($"{patient.Name,-18} | {patient.AssignedDoctor?.Name,-18} | {patient.Email,-25} | {patient.Phone,-13} | {patient.Address,-30}");
                }
            }
            else
            {
                Console.WriteLine("No patients are assigned to you.");
            }

            Console.WriteLine("\nPress any key to return to the menu.");
            Console.ReadKey();
        }

        // Allows the doctor to check details of a specific patient by ID.
        public void CheckPatientDetails()
        {
            Console.Clear();
            Console.WriteLine("-------------------------------");
            Console.WriteLine("| DOTNET Hospital Management System |");
            Console.WriteLine("-------------------------------\n");
            Console.WriteLine("Check Patient Details\n");

            Console.Write("Enter the ID of the patient to check: ");
            int patientId = int.Parse(Console.ReadLine());

            // Find the patient in the list of all patients.
            Patient foundPatient = FileManager.patients.Find(p => p.ID == patientId);

            if (foundPatient != null)
            {
                if (foundPatient.AssignedDoctor != null && foundPatient.AssignedDoctor.ID == this.ID)
                {
                    Console.WriteLine("\nPatient Details\n");
                    Console.WriteLine("Patient            | Doctor             | Email Address             | Phone         | Address");
                    Console.WriteLine("-------------------|--------------------|---------------------------|---------------|------------------------------");
                    Console.WriteLine($"{foundPatient.Name,-18} | {this.Name,-18} | {foundPatient.Email,-25} | {foundPatient.Phone,-13} | {foundPatient.Address,-30}");
                }
                else
                {
                    Console.WriteLine("Error: This patient is not assigned to you.");
                }
            }
            else
            {
                Console.WriteLine("Error: No patient found with the given ID.");
            }

            Console.WriteLine("\nPress any key to return to the menu.");
            Console.ReadKey();
        }

        // Lists all appointments for a specific patient assigned to the doctor.
        public void ListAppointmentsWithPatient()
        {
            Console.Clear();
            Console.WriteLine("-------------------------------");
            Console.WriteLine("| DOTNET Hospital Management System |");
            Console.WriteLine("-------------------------------\n");
            Console.WriteLine("Appointments With\n");

            Console.Write("Enter the ID of the patient you would like to view appointments for: ");
            int patientId = int.Parse(Console.ReadLine());

            // Find the patient in the list of all patients.
            Patient foundPatient = FileManager.patients.Find(p => p.ID == patientId);

            if (foundPatient != null)
            {
                // Get appointments for the doctor with the specific patient.
                var doctorAppointments = FileManager.appointments.FindAll(a => a.Doctor.ID == this.ID && a.Patient.ID == foundPatient.ID);

                if (doctorAppointments.Count > 0)
                {
                    Console.WriteLine("\nDoctor             | Patient           | Description");
                    Console.WriteLine("-------------------|-------------------|----------------------------");

                    foreach (var appointment in doctorAppointments)
                    {
                        Console.WriteLine($"{appointment.Doctor.Name,-18} | {appointment.Patient.Name,-17} | {appointment.Description}");
                    }
                }
                else
                {
                    Console.WriteLine("No appointments found between you and this patient.");
                }
            }
            else
            {
                Console.WriteLine("Error: No patient found with the given ID.");
            }

            Console.WriteLine("\nPress any key to return to the menu.");
            Console.ReadKey();
        }

        // Loads doctor data from a file and returns a list of Doctor objects.
        public static List<Doctor> LoadDoctorsFromFile(string filePath)
        {
            List<Doctor> doctors = new List<Doctor>();

            if (!File.Exists(filePath))
            {
                Console.WriteLine($"Error: File not found at {filePath}");
                return doctors;
            }

            using (TextFieldParser parser = new TextFieldParser(filePath))
            {
                parser.TextFieldType = FieldType.Delimited;
                parser.SetDelimiters(",");

                while (!parser.EndOfData)
                {
                    try
                    {
                        string[] fields = parser.ReadFields();

                        if (fields.Length == 6)
                        {
                            int id = int.Parse(fields[0]);
                            string name = fields[1];
                            string password = fields[2];
                            string address = fields[3];
                            string email = fields[4];
                            string phone = fields[5];

                            Doctor newDoctor = new Doctor(id, name, password, address, email, phone);
                            doctors.Add(newDoctor);
                        }
                        else
                        {
                            Console.WriteLine($"Error: Invalid line format. Expected 6 fields but found {fields.Length}.");
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Error loading doctor: {ex.Message}");
                    }
                }
            }

            return doctors;
        }

        // Saves the list of Doctor objects to a file.
        public static void SaveDoctorsToFile(string filePath, List<Doctor> doctors)
        {
            using (StreamWriter writer = new StreamWriter(filePath))
            {
                foreach (var doctor in doctors)
                {
                    writer.WriteLine($"{doctor.ID},{doctor.Name},{doctor.Password},\"{doctor.Address}\",{doctor.Email},{doctor.Phone}");
                }
            }
        }
    }
}

