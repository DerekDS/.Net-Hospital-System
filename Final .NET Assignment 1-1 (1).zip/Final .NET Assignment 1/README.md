1. To run the app, launch the executable "Final .NET Assignment 1" Application in \bin\Debug\net8.0
2. Login using any of the credentials stored in the adminstrators, patients or doctors txt files (located in the same place) using the ID and password. 
The format in these files is (ID,name,password,"address",email,phone no.)
